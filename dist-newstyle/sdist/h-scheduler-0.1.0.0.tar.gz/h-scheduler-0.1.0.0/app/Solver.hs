module Solver where

import qualified Control.Monad.Trans.Class as Trans

--type constraint

